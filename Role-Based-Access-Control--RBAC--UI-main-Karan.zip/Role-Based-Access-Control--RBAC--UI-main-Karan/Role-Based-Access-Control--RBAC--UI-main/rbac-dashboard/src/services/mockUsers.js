const mockUsers = [
    { id: 1, name: 'Nikhil Shekhar', email: 'nikhil@example.com', role: 'Admin', status: 'Active' },
    { id: 2, name: 'Premal Kadam', email: 'premal123@example.com', role: 'Editor', status: 'Inactive' },
    { id: 3, name: 'Aniket Shelar', email: 'aniket@example.com', role: 'Viewer', status: 'Active' },
  ];
  
  export default mockUsers;
  